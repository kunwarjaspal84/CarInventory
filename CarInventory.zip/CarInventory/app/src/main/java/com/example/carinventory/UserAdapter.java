package com.example.carinventory;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {
    @NonNull

    List<model> carNames;
    public Context mCtx;
    LayoutInflater layoutInflater;

    Activity activity;

    public UserAdapter(Context mCtx,List<model> carNames) {

        this.carNames = carNames;
        layoutInflater = LayoutInflater.from(mCtx);
        this.mCtx = mCtx;
        this.activity = activity;

    }

    public class UserViewHolder extends RecyclerView.ViewHolder{

        TextView textView;

        ConstraintLayout constraintLayout;
        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView4);
            constraintLayout = itemView.findViewById(R.id.layout);

        }

    }
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlecar,parent,false);
        UserViewHolder userViewHolder = new UserViewHolder(view);
        return userViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, final int position) {

        holder.textView.setText(carNames.get(position).name);
        //holder.textView.setText(carNames.get(position).modl);
        //holder.textView.setText(carNames.get(position).price);
        //holder.textView.setText(carNames.get(position).color);
        //Log.e("kghchjejf",carNames.get(position).modl);

        holder.constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toast.makeText(mCtx, "Le Bai :" + carNames.get(position).getColor(), Toast.LENGTH_SHORT).show();
                String CarName =carNames.get(position).getName();
                String Color =  carNames.get(position).getColor();
                String Model =  carNames.get(position).getModl();
                String Price =  carNames.get(position).getPrice();
                int id =  carNames.get(position).getId();
                Context context = v.getContext();


                //Log.e("ghfrdshbrvdhh",CarName);
                // Intent intent =  v.getContext().startActivity(new Intent(v.getContext(),Details.class));
                Intent intent = new Intent(context,UserSideDetails.class);
                intent.putExtra("Name",CarName);
                intent.putExtra("Model",Model);
                intent.putExtra("Price", Price);
                intent.putExtra("Color",Color);
                intent.putExtra("id",id);


                context.startActivity(intent);

            }
        });
    }


    @Override
    public int getItemCount() {
        return carNames.size();
    }

    }
