package com.example.carinventory;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class CarAdapter extends RecyclerView.Adapter<CarAdapter.CarViewHolder> {
    List<model> carNames;
    public Context  mCtx;
    LayoutInflater layoutInflater;
    Activity activity;

    CarAdapter(Context mCtx,List<model> carNames){

        this.carNames = carNames;
        layoutInflater = LayoutInflater.from(mCtx);
        this.mCtx = mCtx;
        this.activity = activity;

    }

    public class CarViewHolder extends RecyclerView.ViewHolder{

        TextView textView;
        ConstraintLayout constraintLayout;

        public CarViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView4);
            constraintLayout = itemView.findViewById(R.id.layout);
        }
    }

    @NonNull
    @Override
    public CarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlecar,parent,false);
        CarViewHolder carViewHolder = new CarViewHolder(view);
        return carViewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull CarViewHolder holder, final int position) {

        holder.textView.setText(carNames.get(position).name);
        //holder.textView.setText(carNames.get(position).modl);
        //holder.textView.setText(carNames.get(position).price);
        //holder.textView.setText(carNames.get(position).color);
        //Log.e("kghchjejf",carNames.get(position).modl);

        holder.constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Toast.makeText(mCtx, "Le Bai :" + carNames.get(position).getColor(), Toast.LENGTH_SHORT).show();
                String CarName =carNames.get(position).getName();
                String Color =  carNames.get(position).getColor();
                String Model =  carNames.get(position).getModl();
                String Price =  carNames.get(position).getPrice();
                int id =  carNames.get(position).getId();
                Context context = v.getContext();


                //Log.e("ghfrdshbrvdhh",CarName);
                // Intent intent =  v.getContext().startActivity(new Intent(v.getContext(),Details.class));
                Intent intent = new Intent(context,Details.class);
                intent.putExtra("Name",CarName);
                intent.putExtra("Model",Model);
                intent.putExtra("Price", Price);
                intent.putExtra("Color",Color);
                intent.putExtra("id",id);


                context.startActivity(intent);

            }
        });


    }

    @Override
    public int getItemCount() {
        return carNames.size();
    }

}
