package com.example.carinventory;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class carsView extends AppCompatActivity {

    DatabaseHelper db;
    EditText carName,color,price,model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cars_view);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        db = new DatabaseHelper(this);

        carName = findViewById(R.id.editText5);
        model = findViewById(R.id.editText6);
        price = findViewById(R.id.editText7);
        color = findViewById(R.id.editText8);
    }

    public void addCar(View view){

        addCarData();
    }

    public void addCarData(){


        String name = carName.getText().toString();

        String models = model.getText().toString();
        String prices = price.getText().toString();
        String colors = color.getText().toString();

        if(name.matches("") || models.matches("")  || prices.matches("")  || colors.matches("")){

            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Please fill all fields!");
            builder.setCancelable(true);
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.show();


        }else {

            Boolean data = db.addCars(name, models, prices, colors);
            if (data == true) {

                Toast.makeText(carsView.this, "Car Inserted", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(carsView.this,CarsUserView.class);
                startActivity(intent);

            } else {
                Toast.makeText(carsView.this, "no insertion", Toast.LENGTH_LONG).show();

            }

        }
    }

    public void View(View view){

        Intent intent = new Intent(carsView.this,CarsUserView.class);
        startActivity(intent);


    }


}
