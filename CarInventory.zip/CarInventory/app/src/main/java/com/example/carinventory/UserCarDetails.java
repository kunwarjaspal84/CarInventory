package com.example.carinventory;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserCarDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_car_details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
