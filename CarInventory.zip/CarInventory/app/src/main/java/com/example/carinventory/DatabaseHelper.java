package com.example.carinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String TABLE_NAME = "users";
    public static final String TABLE_NAME_1 = "cars";
    public static final String TABLE_NAME_2 = "admin";
    public static final int DATABASE_VERSION = 12;
    public static final String DATABASE_NAME = "carDatabase.db";
    public static final String ID = "id";
    public static final String EMAIL = "email";
    public static final String PASSWORD = "password";
    public static final String NAME = "name";
    public static final String MODEL = "model";
    public static final String PRICE = "price";
    public static final String COLOR = "color";
    public static final String TABLE_CREATE = "create table " + TABLE_NAME + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            EMAIL + " TEXT, " +
            PASSWORD + " VARCHAR )";

    public static final String TABLE_CREATE_1 = "create table " + TABLE_NAME_1 + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            NAME + " TEXT, " +
            MODEL + " TEXT, " +
            PRICE + " TEXT, " +
            COLOR + " TEXT )";

    public static final String TABLE_CREATE_2 = "create table " + TABLE_NAME_2 + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            EMAIL + " TEXT, " +
            PASSWORD + " VARCHAR )";





    public DatabaseHelper(@Nullable Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.e(TAG, "Create application database");

        SQLiteDatabase db = this.getWritableDatabase();
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        Log.e(TAG, "Create table");

        db.execSQL(TABLE_CREATE);
        db.execSQL(TABLE_CREATE_1);
        db.execSQL(TABLE_CREATE_2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        Log.e(TAG, "Create application Upgrading");

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_1);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_2);
            onCreate(db);

    }

    public boolean addData(String emails,String passwords){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email",emails);
        contentValues.put("password",passwords);

        long result = db.insert(TABLE_NAME,null,contentValues);
        if (result == -1){
            return false;
        }else{
            return true;
        }

    }

    public Boolean getData(String emails,String passwords){

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from users where email=? and password=?",new String[]{emails,passwords},null);
        if(cursor.getCount() > 0) {
            return true;
        }else{
            return false;
        }

    }

    public boolean addCars(String name,String models,String prices,String colors){
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("name",name);
            contentValues.put("model",models);
            contentValues.put("color",colors);
            contentValues.put("price",prices);

        long result = db.insert(TABLE_NAME_1,null,contentValues);
            if(result == -1){

                return false;

            }else{

                return true;
            }
    }

    public List<model> getCars(){

        List<model> carDetails = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from cars",null);

        while (cursor.moveToNext()){

            int index = cursor.getColumnIndex(NAME);
            int index1 = cursor.getColumnIndex(MODEL);
            int index2 = cursor.getColumnIndex(PRICE);
            int index3 = cursor.getColumnIndex(COLOR);
            int index4 = cursor.getColumnIndex(ID);


            String name = cursor.getString(index);
            String modl = cursor.getString(index1);
            String color = cursor.getString(index3);
            String price = cursor.getString(index2);
            int id = cursor.getInt(index4);

            model model = new model(name,modl,price,color,id);
            carDetails.add(model);
        }

        return carDetails;

    }

    public boolean emailCheck(String emails){

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from users where email=?",new String[] {emails});
        if(cursor.getCount()>0){
            return true;
        }else{
            return false;
        }
    }

    public boolean getAdmin(String emails,String passwords){

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from admin where email=? and password=?",new String[]{emails,passwords});
        if(cursor.getCount()>0){

            return true;
        }else{

            return false;
        }
    }

    public boolean adminaEmailCheck(String emails){

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from admin where email=?",new String[]{emails});
        if(cursor.getCount()>0){
            return true;

        }else{

            return false;
        }
    }

    public int deleteCar(int id){

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

       return sqLiteDatabase.delete(TABLE_NAME_1,"id=?",new String[]{String.valueOf(id)});


    }





}
