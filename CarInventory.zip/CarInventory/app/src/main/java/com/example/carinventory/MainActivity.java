package com.example.carinventory;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    EditText email,password;
    String emails,passwords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseHelper = new DatabaseHelper(this);



        email = findViewById(R.id.editText);
        password = findViewById(R.id.editText2);
    }

    public void adData(){

        emails = email.getText().toString();
        passwords = password.getText().toString();
        String emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";



        if(emails.matches(emailPattern) == false || emails.matches("")) {

            //Toast.makeText(MainActivity.this, "Please email", Toast.LENGTH_LONG).show();
            email.setError("Please fill valid email");

        }else if(passwords.matches("")) {

            //Toast.makeText(MainActivity.this, "Please fill password", Toast.LENGTH_LONG).show();
            password.setError("Please fill password");

        }else{

            Boolean a = databaseHelper.emailCheck(emails);
            Boolean b = databaseHelper.adminaEmailCheck(emails);

            if(a == true || b == true){

                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("This email already exists!");
                builder.setCancelable(true);
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();


            }else {

                boolean addData = databaseHelper.addData(emails, passwords);

                if (addData == true) {

                    // Toast.makeText(MainActivity.this, "Registarion succesfull", Toast.LENGTH_LONG).show();
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Registration succesfull!");
                    builder.setCancelable(true);
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Intent intent = new Intent(MainActivity.this, Register.class);
                            startActivity(intent);
                        }
                    });
                    builder.show();
                }
            }
        }


    }

    public void login(View view){

        adData();
    }



    public void registration(View view){

        Intent intent = new Intent(MainActivity.this,Register.class);
        startActivity(intent);

    }
}
