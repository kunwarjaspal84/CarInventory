
package com.example.carinventory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.example.carinventory.R;
import static com.example.carinventory.DatabaseHelper.TABLE_NAME_1;

public class Details extends AppCompatActivity {
    TextView nam,model,price,color;
    String i;
    String m;
    String c;
    String p;
    int id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Intent intent = getIntent();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (intent != null) {

            nam = findViewById(R.id.textView5);
            model = findViewById(R.id.textView6);
            color = findViewById(R.id.textView7);
            price = findViewById(R.id.textView8);

            i = intent.getStringExtra("Name");
            m = intent.getStringExtra("Model");
            c = intent.getStringExtra("Color");
            p = intent.getStringExtra("Price");
            id = intent.getIntExtra("id",0);
            nam.setText(i);
            model.setText(m);
            color.setText(c);
            price.setText(p);

        }



    }

    public void back(View view){

        Intent intent = new Intent(Details.this,carsView.class);
        startActivity(intent);
    }

    public void delete(View view){

        delete();
    }

    public void delete(){


        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        databaseHelper.deleteCar(id);

        if(databaseHelper != null) {

            Log.e("fffffffffffff", String.valueOf(id));

            nam.setText("");
            model.setText("");
            price.setText("");
            color.setText("");
            Intent intent = new Intent(Details.this,CarsUserView.class);
            startActivity(intent);
        }


    }

    public void View(View view){

        Intent intent = new Intent(Details.this,carsView.class);
        startActivity(intent);


    }

    public void Add(View view){

        Toast.makeText(Details.this,"Logged Out!",Toast.LENGTH_LONG).show();


        Intent intent = new Intent(Details.this,Register.class);
        startActivity(intent);


    }


}
