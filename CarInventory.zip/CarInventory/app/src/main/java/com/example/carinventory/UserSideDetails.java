package com.example.carinventory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class UserSideDetails extends AppCompatActivity {
    TextView nam,model,price,color;
    String i;
    String m;
    String c;
    String p;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_side_details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent intent = getIntent();

        if (intent != null) {

            nam = findViewById(R.id.textView5);
            model = findViewById(R.id.textView6);
            color = findViewById(R.id.textView7);
            price = findViewById(R.id.textView8);

            i = intent.getStringExtra("Name");
            m = intent.getStringExtra("Model");
            c = intent.getStringExtra("Color");
            p = intent.getStringExtra("Price");
            id = intent.getIntExtra("id",0);
            nam.setText(i);
            model.setText(m);
            color.setText(c);
            price.setText(p);
            //Toast.makeText(Details.this,"Le cho : !" + i,Toast.LENGTH_LONG).show();
        }
    }

    public void Add(View view){

        Toast.makeText(UserSideDetails.this,"Logged Out!",Toast.LENGTH_LONG).show();
        Intent intent = new Intent(UserSideDetails.this,Register.class);
        startActivity(intent);



    }
}
