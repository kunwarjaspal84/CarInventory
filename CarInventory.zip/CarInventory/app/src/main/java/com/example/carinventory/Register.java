package com.example.carinventory;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;

public class Register extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    EditText id,passwod;
    String emails,passwords;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        databaseHelper = new DatabaseHelper(this);


    }

    public void login(View view){

        loginMethod();

    }





    public void loginMethod(){

        id = findViewById(R.id.editText3);
        passwod = findViewById(R.id.editText4);

        emails = id.getText().toString();
        passwords = passwod.getText().toString();

        Boolean a = databaseHelper.getData(emails, passwords);
        Boolean b = databaseHelper.getAdmin(emails,passwords);

        if(emails.matches("") || passwords.matches("")) {

            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Please fill all fields!");
            builder.setCancelable(true);
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.show();

        }else{

            if (a == true) {

                Toast.makeText(Register.this, "User logged in successfully!", Toast.LENGTH_LONG).show();

                Intent i = new Intent(Register.this, UserRecyclerView.class);
                i.putExtra("a", true);
                startActivity(i);

            } else if (b == true) {

                Toast.makeText(Register.this, "Admin logged in successfully!", Toast.LENGTH_LONG).show();


                Intent i = new Intent(Register.this, carsView.class);
                i.putExtra("b", true);
                startActivity(i);

            } else {
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Invalid id/Password");
                builder.setCancelable(true);
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();

            }
        }
    }
}
